<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require_once __DIR__ . '/../app/route/route.web.php';


// use function App\Route\handle_route;


// handle_route();
